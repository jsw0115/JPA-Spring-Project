CREATE DATABASE IF NOT EXISTS `tbl_maxrent_stat`

CREATE TABLE IF NOT EXISTS `tbl_maxrent_stat` (
	`rent_no` INT(11) NOT NULL AUTO_INCREMENT,
	`room_cnt` INT(11) NULL DEFAULT NULL,
	`month_rent` DECIMAL(12,0) NULL DEFAULT NULL,
	`unit_rent` DECIMAL(12,0) NULL DEFAULT NULL,
	`maint_cost` DECIMAL(12,0) NULL DEFAULT NULL,
	`best_rent` DECIMAL(12,0) NULL DEFAULT NULL,
	`rent_room_cnt` INT(11) NULL DEFAULT NULL,
	`max_profit` DECIMAL(12,0) NULL DEFAULT NULL,
	`reg_user` VARCHAR(32) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`ip_addr` VARCHAR(15) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`reg_date` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`rent_no`) USING BTREE
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1004
;

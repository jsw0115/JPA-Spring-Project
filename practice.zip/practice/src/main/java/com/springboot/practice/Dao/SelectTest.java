package com.springboot.practice.Dao;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

public class SelectTest {
    private JdbcTemplate jdbcTemplate;

    public SelectTest() {
        this.jdbcTemplate = new JdbcTemplate();
    }



}

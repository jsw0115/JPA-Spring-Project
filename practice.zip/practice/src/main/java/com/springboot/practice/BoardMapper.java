package com.springboot.practice;

import java.util.List;

public class BoardMapper {

}
